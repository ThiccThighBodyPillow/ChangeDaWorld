/* mbed Microcontroller Library
 * Copyright (c) 2019 ARM Limited
 * SPDX-License-Identifier: Apache-2.0
 */

//IKT104 Group 16
//Assignment 5, timers


#include "mbed.h"
#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include "DFRobot_RGBLCD.h"

//interrupt states
volatile bool rst_state = false;
volatile bool paus_state = false;

//Variable for counter
int seconds;

// Forward declare interrupts
void rst(){rst_state=!rst_state;};
void paus(){paus_state=!paus_state;};

//[trap card] reduces value of seconds by one (1) when activated
void tickDown(){seconds=seconds-1;}

//Declare timeout named "timer"
Timeout timer;

//IO
 
DigitalOut buzzer(A2); //self destruct
DigitalIn pb1(D1);  // +5sec
DigitalIn pb2(D2);  // -5sec
InterruptIn pb3(D3);  // Start / pause
InterruptIn pb4(D4);  //Reset

//Connect Display to I2C 
DFRobot_RGBLCD lcd(16,2,D14,D15);


 
//STATUS BEEP
void beep(int t) {
    while(t --){
        buzzer = 1;
        thread_sleep_for(1);
        buzzer = 0;
        thread_sleep_for(1);
    }
}

//a single beepo period
void alarm() {
        buzzer = 1;
        thread_sleep_for(1);
        buzzer = 0;
        thread_sleep_for(1);
    }


 

 
 
int main () {  


//IO pinmodes
pb1.mode(PullUp);
pb2.mode(PullUp);
pb3.mode(PullUp);
pb4.mode(PullUp);
thread_sleep_for(500);

//Interrupt handling
pb3.fall(&paus);
pb4.fall(&rst);

    //Main loop, endless 
while(true){
seconds=60;

// Less goo prompt
    lcd.init();
    lcd.clear();
    lcd.printf("Countdown Timer");
    beep(100); // init buzzer
    thread_sleep_for(1000);

paus_state = true; //yes pause
rst_state = false; //not reset
thread_sleep_for(500);

//What to do when not reset
while(rst_state==false){




    
    



//Paused behavior
if(paus_state==true){
while(true){


lcd.clear ();
lcd.setRGB(255, 0, 0);
lcd.printf("PAUSED tmr: %02ds",seconds);
thread_sleep_for(200);

if(pb2==1){seconds=seconds+5;};
if(pb1==1){seconds=seconds-5;};


if(paus_state==false){break;};
if(rst_state==true){break;};
}
}




//Timer run behavior
else{
while(paus_state==false){

timer.attach(&tickDown, 1s); // timeout counts down by one second each, you know, second. I'm known to speak elaquently.

lcd.clear ();
lcd.setRGB(255, 255, 0);
lcd.printf("Remaining: %02ds",seconds);
thread_sleep_for(1000);


//Sound alarm
if(seconds<1){seconds=60; lcd.clear(); lcd.setRGB(255, 0, 255); lcd.printf("TIMER DONE"); while(rst_state==false&&paus_state==false){alarm();}  };




if(paus_state==true){break;};
if(rst_state==true){break;};
}
}




//Restart main function when the
if(rst_state==true){break;};
}



} 


}



//                                                                                      I PULL UP                                                          